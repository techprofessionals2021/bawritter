<?php

namespace App\Enums;

abstract class PaymentReason
{
    const order 		    = 'order';
    const wallettopup 	    = 'wallettopup';

}

