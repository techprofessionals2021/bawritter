<?php

namespace App\Exceptions;

use Exception;

class NoUnbilledWorkException extends Exception
{
    //
}
