<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">  
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php if(Session::has('seo_was_set')): ?>
<?php echo SEO::generate(); ?>

<?php endif; ?>
<link href="https://fonts.googleapis.com/css2?family=Nunito&display=swap" rel="stylesheet">
<link href="<?php echo e(asset('css/theme.min.css')); ?>" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="https://use.fontawesome.com/releases/v5.13.0/css/all.css">
<?php echo settings('website_header_script'); ?>

<?php echo $__env->make('website.google_analytics', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
<?php echo $__env->make('website.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="app">
    <?php echo $__env->yieldContent('content'); ?>  
</div>
<?php echo $__env->make('cookieConsent::index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('website.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
<script src="<?php echo e(asset('js/theme.min.js')); ?>"></script>
<?php echo settings('website_footer_script'); ?>

</body>
</html><?php /**PATH C:\xampp\htdocs\writing-order-management\resources\views/website/layouts/template.blade.php ENDPATH**/ ?>