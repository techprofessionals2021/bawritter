
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('website.partials.home_page_section_1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('website.partials.home_page_section_2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('website.partials.home_page_section_3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('website.partials.home_page_section_4', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="text-center mb-100">
    	<a href="<?php echo e(route('instant_quote')); ?>" class="boxed_btn"><?php echo homepage('order_page_link_text'); ?></a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\writing-order-management\resources\views/website/index.blade.php ENDPATH**/ ?>