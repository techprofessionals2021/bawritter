
<?php $__env->startSection('title', $data['entity']); ?>
<?php $__env->startSection('content'); ?>
<div class="container page-container">
   <div class="row">
      <div class="col-md-6">
         <h4>List of <?php echo e($data['entity']); ?></h4>
         <br>
      </div>
      <div class="col-md-6">
         <?php if(in_array($data['type'],['admin', 'staff'])): ?>
         <a href="<?php echo e(route('user_invitation', ['type' => $data['type']])); ?>" class="btn btn-success float-md-right">
         <i class="fas fa-paper-plane"></i> 
         Invite <?php echo e($data['entity_singular']); ?>

         </a>
         <?php endif; ?>
      </div>
      <div class="clearfix"></div>  
      <div class="col-md-4">
         <?php echo $__env->make('user.partials.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
      <div class="col-md-8">
         <table id="table" class="w-100">
            <thead>
               <tr>
                  <th scope="col"></th>
               </tr>
            </thead>
         </table>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(function(){

      $('.multSelectpicker').select2({
        theme: 'bootstrap4',
      });
   
        
      var oTable = $('#table').DataTable({
        "bLengthChange": false,
          searching: false,
          processing: true,
          serverSide: true,    
          "ordering": false,            
          "ajax": {
                  "url": "<?php echo route('datatable_users', ['type' => $data['type'] ]); ?>",
                  "type": "POST",
                  'headers': {
                      'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                  },                   
                  "data": function ( d ) {
                      d.search = $("input[name=search]").val();

                      if($("#inactive").prop("checked"))
                      {
                        d.inactive = 1;  
                      }

                      var tags = $("#tag_id").val();

                      if(tags)
                      {
                        d.tags = tags;
                      }              
                     
                  }
          },
          columns: [
              {data: 'user_html', name: 'user_html'}         
          ]
      }).
      on('page.dt', function() {
          $('html, body').animate({
            scrollTop: $(".dataTables_wrapper").offset().top
          }, 'slow');
        });

     $('#search-form').on('submit', function(e) {
      oTable.draw();
      e.preventDefault();
    });

    });      
</script>
<?php $__env->stopPush(); ?>
   

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\writing-order-management\resources\views/user/index.blade.php ENDPATH**/ ?>