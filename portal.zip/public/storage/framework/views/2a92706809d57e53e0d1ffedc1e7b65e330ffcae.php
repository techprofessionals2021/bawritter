
<?php $__env->startSection('title', $data['title']); ?>
<?php $__env->startSection('content'); ?>
<div class="container page-container" id="app">
 <h2><?php echo e($data['title']); ?></h2>
 <br>
  <order :services="<?php echo e(json_encode($data['service_id_list'])); ?>"
:levels="<?php echo e(json_encode($data['work_level_id_list'])); ?>"
:urgencies="<?php echo e(json_encode($data['urgency_id_list'])); ?>"
:spacings="<?php echo e(json_encode($data['spacings_list'])); ?>"
:user_id="<?php echo e((!Auth::guest()) ? auth()->user()->id : 'false'); ?>"
:add_to_cart_url="'<?php echo e(route('add_to_cart')); ?>'"
:restricted_order_page_url="'<?php echo e(route('order_page')); ?>'"
:create_account_url="'<?php echo e(route('register')); ?>'"
:upload_attachment_url="'<?php echo e(route('order_upload_attachment')); ?>'"
:additional_services_by_service_id_url= "'<?php echo e(route('additional_services_by_service_id')); ?>'"
:term_and_condition_url="'<?php echo e(route('terms_and_conditions')); ?>'"
:privacy_policy_url= "'<?php echo e(route('privacy_policy')); ?>'"
 ></order>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\writing-order-management\resources\views/order/create.blade.php ENDPATH**/ ?>