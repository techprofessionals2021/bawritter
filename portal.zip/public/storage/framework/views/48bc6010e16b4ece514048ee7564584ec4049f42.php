<footer class="footer mt-auto py-3">
  <div class="container">
    <span class="text-muted">&copy; <?php echo e(get_company_name()); ?> <?php echo e(date("Y")); ?></span>
  </div>
</footer><?php /**PATH C:\xampp\htdocs\writing-order-management\resources\views/layouts/footer.blade.php ENDPATH**/ ?>