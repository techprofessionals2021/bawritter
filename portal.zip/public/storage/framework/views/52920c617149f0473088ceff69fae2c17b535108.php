<?php if($tracking_code = settings('google_analytics_tracking_code')) { ?>
<script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo e($tracking_code); ?>"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', '<?php echo e($tracking_code); ?>');
</script>

<?php } ?>

<?php /**PATH C:\xampp\htdocs\writing-order-management\resources\views/website/google_analytics.blade.php ENDPATH**/ ?>