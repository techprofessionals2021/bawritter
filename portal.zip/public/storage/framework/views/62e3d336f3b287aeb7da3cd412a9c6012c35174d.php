<div class="mb-100">
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="single_about_info text-center pb-5">
	            <h3><?php echo homepage('section_2_title'); ?></h3>
	            <div><?php echo homepage('section_2_sub_title'); ?></div>
            </div>
		</div>
		<?php if(isset($data['services']) && count($data['services']) > 0): ?>
			<?php $__currentLoopData = $data['services']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $services): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-md-3">
				<ul class="font-14">
					<?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($service['name']); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endif; ?>
	</div>	
</div>
</div><?php /**PATH C:\xampp\htdocs\writing-order-management\resources\views/website/partials/home_page_section_2.blade.php ENDPATH**/ ?>