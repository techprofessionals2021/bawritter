<nav class="navbar navbar-expand-md shadow-sm navbar-background">
   <div class="container">
      <a class="navbar-brand" href="<?php echo e(url('/')); ?>">                    
      <img class="logo" src="<?php echo e(get_company_logo()); ?>" alt="<?php echo e(config('app.name', 'ProWriter')); ?>">
      </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
      <i class="fas fa-bars"></i>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
         <ul class="navbar-nav mr-auto">
            <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?> 
            <li class="nav-item">
               <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
            </li>
            <li class="nav-item">
               <a class="nav-link" href="<?php echo e(route('orders_list')); ?>">Orders</a>
            </li>
            <li class="nav-item">
               <a class="nav-link" href="<?php echo e(route('users_list', ['type' => 'customer'])); ?>">Customers</a>
            </li>
            <li class="nav-item">
               <a class="nav-link" href="<?php echo e(route('users_list', ['type' => 'staff'])); ?>">
               Writers
               </a>
            </li>
            <li class="nav-item dropdown">
               <a id="payments" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
               Payments <span class="caret"></span>
               </a>
               <div class="dropdown-menu" aria-labelledby="payments">
                  <a class="dropdown-item" href="<?php echo e(route('pending_payment_approvals')); ?>">Pending Approval</a>
                  <a class="dropdown-item" href="<?php echo e(route('payments_list')); ?>">Payments List</a>
                  <a class="dropdown-item" href="<?php echo e(route('wallet_transactions')); ?>">Wallet Transactions</a>
               </div>
            </li>
            <li class="nav-item dropdown">
               <a id="managerial" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
               Manage <span class="caret"></span>
               </a>
               <div class="dropdown-menu" aria-labelledby="managerial">
                  <a class="dropdown-item" href="<?php echo e(route('bills_list')); ?>">Bills from Writers</a>
                  <a class="dropdown-item" href="<?php echo e(route('settings_main_page')); ?>">Settings</a>
                  <a class="dropdown-item" href="<?php echo e(route('users_list', ['type' => 'admin'])); ?>">Admin Users</a>
                  <a class="dropdown-item" href="<?php echo e(route('job_applicants')); ?>">Job Applicants</a>
               </div>
            </li>
            <li class="nav-item dropdown">
               <a id="managerial" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
               Reports <span class="caret"></span>
               </a>
               <div class="dropdown-menu" aria-labelledby="managerial">
                  <a class="dropdown-item" href="<?php echo e(route('income_statement')); ?>">Income Statement</a>
                  <a class="dropdown-item" href="<?php echo e(route('total_wallet_balance')); ?>">Total Wallet Balance</a>

               </div>
            </li>

            <?php endif; ?>
            <?php if(auth()->check() && auth()->user()->hasRole('staff')): ?>    
            <?php if(strtolower(settings('enable_browsing_work')) == 'yes'): ?>
            <li class="nav-item">
               <a class="nav-link" href="<?php echo e(route('browse_work')); ?>">Browse Work</a>
            </li>
            <?php endif; ?>
            <li class="nav-item">
               <a class="nav-link" href="<?php echo e(route('tasks_list')); ?>">My Tasks</a>
            </li>
            <li class="nav-item dropdown">
               <a id="payment_request" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
               Payment Request <span class="caret"></span>
               </a>
               <div class="dropdown-menu" aria-labelledby="payment_request">
                  <a class="dropdown-item" href="<?php echo e(route('request_for_payment')); ?>">
                  Request for payment
                  </a>
                  <a class="dropdown-item" href="<?php echo e(route('my_requests_for_payment')); ?>">
                  List of payment requests
                  </a>
               </div>
            </li>
            <?php endif; ?>
            <?php if(auth()->guard()->check()): ?>
            <?php if(!auth()->check() || ! auth()->user()->hasRole('staff|admin')): ?>
            <li class="nav-item">
               <a class="nav-link" href="<?php echo e(route('my_orders')); ?>">My Orders</a>
            </li>
            <li class="nav-item">
               <a class="nav-link" href="<?php echo e(route('order_page')); ?>">New Order</a>
            </li>
            <li class="nav-item">
               <a class="nav-link" href="<?php echo e(route('my_account',['group' => 'wallet'])); ?>">My Wallet</a>
            </li>           
            <?php endif; ?>
            <?php endif; ?>
         </ul>

         <ul class="navbar-nav ml-auto">         
            <?php if(auth()->guard()->guest()): ?>
            <?php if(!settings('disable_writer_application')): ?>
            <li class="nav-item">
               <a class="nav-link" href="<?php echo e(route('writer_application_page')); ?>">
                  <?php echo e(settings('writer_application_page_link_title')); ?>

               </a>
            </li>
            <?php endif; ?>
            <li class="nav-item">
               <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
            </li>
            <?php if(Route::has('register')): ?>
            <li class="nav-item">
               <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
            </li>
            <?php endif; ?>
            <?php else: ?>
            <?php if(auth()->check() && auth()->user()->hasAnyRole('staff|admin')): ?>
            <li class="nav-item dropdown" style="z-index: 2000 !important;">                                
               <?php echo $__env->make('layouts.notification_bell', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </li>
            <?php endif; ?>
            <li class="nav-item dropdown" style="z-index: 2000 !important;">
               <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
               <?php echo e(Auth::user()->first_name); ?> <span class="caret"></span>
               </a>
               <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                  
                  <a class="dropdown-item" href="<?php echo e(route('my_account')); ?>">                   
                  My Account
                  </a>
                  <?php if(auth()->check() && auth()->user()->hasAnyRole('staff|admin')): ?>
                  <a class="dropdown-item" href="<?php echo e(route('my_account',['group' => 'wallet'])); ?>">My Wallet</a>
                  <a class="dropdown-item" href="<?php echo e(route('my_orders')); ?>">My Orders</a>    
                  <a class="dropdown-item" href="<?php echo e(route('order_page')); ?>">New Order</a>      
                  
                  <div class="dropdown-divider"></div>
                  <?php endif; ?>
                  <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                     onclick="event.preventDefault();
                     document.getElementById('logout-form').submit();">
                  <?php echo e(__('Logout')); ?>

                  </a>
                  <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                     <?php echo csrf_field(); ?>
                  </form>
               </div>
            </li>
            <?php endif; ?>
         </ul>
      </div>
   </div>
</nav><?php /**PATH C:\xampp\htdocs\writing-order-management\resources\views/layouts/menu.blade.php ENDPATH**/ ?>