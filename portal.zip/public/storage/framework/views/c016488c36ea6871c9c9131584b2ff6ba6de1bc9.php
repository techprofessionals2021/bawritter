<!doctype html>
<html lang="en">
   <head>
     <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">  
     <meta http-equiv="X-UA-Compatible" content="IE=edge" /> 
     <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
     <title><?php echo $__env->yieldContent('title'); ?> - <?php echo e(get_company_name()); ?></title>
     <link href="https://fonts.googleapis.com/css2?family=Nunito&display=swap" rel="stylesheet">
     <link href="<?php echo e(asset('css/app.min.css')); ?>" rel="stylesheet">
     <link rel="stylesheet" type="text/css" href="https://use.fontawesome.com/releases/v5.13.0/css/all.css">
     <?php echo $__env->yieldPushContent('stylesheets'); ?>
   </head>
   <body class="body d-flex flex-column h-100">
      <div id="app" class="flex-grow-1">
         <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <main><?php echo $__env->yieldContent('content'); ?></main>
      </div>
      <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script type="text/javascript">
      window.currencyConfig = <?php echo currencyConfig(); ?>;
</script>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php if($notification = growl_notification()): ?>
<script type="text/javascript">
   $(function () {     
     <?php echo $notification; ?>     
   });
</script>
<?php endif; ?>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\writing-order-management\resources\views/layouts/app.blade.php ENDPATH**/ ?>