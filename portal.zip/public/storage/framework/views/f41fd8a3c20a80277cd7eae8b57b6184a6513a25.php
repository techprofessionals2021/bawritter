<notification
:url_push_notification="'<?php echo e(route('get_push_notification_count')); ?>'"
:url_get_notifications="'<?php echo e(route('get_unread_notifications')); ?>'"
:url_notification_list_page="'<?php echo e(route('notifications_index')); ?>'"
:url_mark_all_as_read="'<?php echo e(route('notification_all_mark_as_read')); ?>'"
></notification>


<?php /**PATH C:\xampp\htdocs\writing-order-management\resources\views/layouts/notification_bell.blade.php ENDPATH**/ ?>