Name : {{ $data['name'] }} <br>
Email : {{ $data['email'] }} <br>
Subject : {{ $data['subject'] }} <br>

<p>
{{ $data['message'] }}
</p>

{{ config('app.name') }}

