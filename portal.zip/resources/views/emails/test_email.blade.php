@component('mail::message')

Hi, 

Congratulation! Your email is configured correctly.


Thanks,<br>
{{ config('app.name') }}
@endcomponent
