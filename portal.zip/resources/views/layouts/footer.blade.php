<footer class="footer mt-auto py-3">
  <div class="container">
    <span class="text-muted">&copy; {{ get_company_name() }} {{ date("Y") }}</span>
  </div>
</footer>